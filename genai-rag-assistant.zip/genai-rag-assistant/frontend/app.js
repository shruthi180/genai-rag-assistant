const sessionId = localStorage.getItem("sessionId") || crypto.randomUUID();

localStorage.setItem("sessionId", sessionId);

async function sendMessage() {

    const messageInput = document.getElementById("message");
    const message = messageInput.value;

    if (!message) return;

    const chatBox = document.getElementById("chat-box");
    const loading = document.getElementById("loading");

    chatBox.innerHTML += `<p><b>You:</b> ${message}</p>`;

    loading.style.display = "block";

    const response = await fetch("http://127.0.0.1:8000/api/chat", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            sessionId: sessionId,
            message: message
        })
    });

    const data = await response.json();

    loading.style.display = "none";

    chatBox.innerHTML += `<p><b>Bot:</b> ${data.reply}</p>`;

    chatBox.scrollTop = chatBox.scrollHeight;

    messageInput.value = "";
}