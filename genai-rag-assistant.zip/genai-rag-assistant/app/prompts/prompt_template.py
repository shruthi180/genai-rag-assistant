PROMPT = '''
You are a helpful assistant.

Use ONLY the provided context to answer.

Context:
{context}

Conversation History:
{history}

Question:
{question}
'''