import chromadb

client = chromadb.Client()

collection = client.get_or_create_collection("knowledge_base")

def add_document(doc_id, embedding, text, metadata):
    collection.add(
        ids=[doc_id],
        embeddings=[embedding],
        documents=[text],
        metadatas=[metadata]
    )

def search_documents(query_embedding, top_k=3):
    results = collection.query(
        query_embeddings=[query_embedding],
        n_results=top_k
    )

    return results