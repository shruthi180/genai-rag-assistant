from openai import OpenAI
from dotenv import load_dotenv
import os

load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def ask_llm(prompt):

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            temperature=0.2,
            messages=[
                {
                    "role": "user",
                    "content": prompt
                }
            ]
        )

        return {
            "reply": response.choices[0].message.content,
            "tokens": response.usage.total_tokens
        }

    except Exception as e:
        return {
            "reply": f"LLM Error: {str(e)}",
            "tokens": 0
        }