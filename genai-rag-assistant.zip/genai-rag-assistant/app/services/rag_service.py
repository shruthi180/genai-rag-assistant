from app.services.embedding_service import get_embedding
from app.vectorstore.chroma_store import search_documents
from app.prompts.prompt_template import PROMPT
from app.services.llm_service import ask_llm
from app.services.memory_service import get_history, add_message

SIMILARITY_THRESHOLD = 0.2

def ask_question(question, session_id):

    query_embedding = get_embedding(question)

    results = search_documents(query_embedding)

    docs = results.get("documents", [[]])[0]
    distances = results.get("distances", [[]])[0]

    if not docs:
        return {
            "reply": "I could not find enough information in the knowledge base to answer this question.",
            "tokensUsed": 0,
            "retrievedChunks": 0
        }

    similarity_score = 1 - distances[0] if distances else 0

    if similarity_score < SIMILARITY_THRESHOLD:
        return {
            "reply": "I could not find enough information in the knowledge base to answer this question.",
            "tokensUsed": 0,
            "retrievedChunks": 0
        }

    history_data = get_history(session_id)

    history = ""

    for item in history_data:
        history += f"{item['role']}: {item['message']}\n"

    context = "\n".join(docs)

    prompt = PROMPT.format(
        context=context,
        history=history,
        question=question
    )

    llm_response = ask_llm(prompt)

    add_message(session_id, "user", question)
    add_message(session_id, "assistant", llm_response["reply"])

    return {
        "reply": llm_response["reply"],
        "tokensUsed": llm_response["tokens"],
        "retrievedChunks": len(docs)
    }