from fastapi import FastAPI
from app.models.schemas import ChatRequest
from app.services.rag_service import ask_question

app = FastAPI()

@app.get("/health")
def health():
    return {"status": "healthy"}

@app.post("/api/chat")
def chat(request: ChatRequest):

    if not request.message:
        return {"error": "Message field is required"}

    response = ask_question(request.message, request.sessionId)

    return response