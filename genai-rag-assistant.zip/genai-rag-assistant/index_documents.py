import json
from app.services.embedding_service import get_embedding
from app.vectorstore.chroma_store import add_document
from app.utils.chunker import chunk_text

with open("docs.json", "r") as f:
    docs = json.load(f)

for doc in docs:
    chunks = chunk_text(doc["content"])

    for idx, chunk in enumerate(chunks):
        embedding = get_embedding(chunk)

        add_document(
            f"{doc['title']}_{idx}",
            embedding,
            chunk,
            {
                "title": doc["title"],
                "chunk_id": idx,
                "source": doc["title"]
            }
        )

print("Documents indexed successfully")