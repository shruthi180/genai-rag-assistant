# GenAI RAG Assistant

## Setup

```bash
pip install -r requirements.txt
```

Create `.env`

```env
OPENAI_API_KEY=your_key
```

## Index Documents

```bash
python index_documents.py
```

## Run Backend

```bash
uvicorn app.main:app --reload
```

## Open Frontend

Open:

frontend/index.html